#! /bin/bash
make clean
clear
make
