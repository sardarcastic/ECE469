#ifndef __USERPROG__
#define __USERPROG__

#define S2_TO_RUN "S2Gen.dlx.obj"
#define Co_TO_RUN "CoGen.dlx.obj"
#define REACT1_TO_RUN "react1.dlx.obj"
#define REACT2_TO_RUN "react2.dlx.obj"
#define REACT3_TO_RUN "react3.dlx.obj"


#endif
